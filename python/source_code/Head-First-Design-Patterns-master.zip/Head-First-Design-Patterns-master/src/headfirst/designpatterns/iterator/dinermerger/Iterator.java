package headfirst.designpatterns.iterator.dinermerger;

public interface Iterator {
	boolean hasNext();
	MenuItem next();
}
