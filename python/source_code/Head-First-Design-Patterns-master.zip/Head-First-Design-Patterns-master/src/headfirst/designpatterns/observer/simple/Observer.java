package headfirst.designpatterns.observer.simple;

public interface Observer {
	public void update(int value);
}
