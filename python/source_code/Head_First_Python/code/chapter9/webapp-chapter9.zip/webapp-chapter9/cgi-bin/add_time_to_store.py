#! /usr/local/bin/python3

import cgi
import time

form = cgi.FieldStorage()

# Open a connection to the database and add the timing value.


