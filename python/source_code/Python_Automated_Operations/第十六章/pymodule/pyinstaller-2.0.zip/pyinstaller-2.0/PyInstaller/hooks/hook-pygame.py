# Hook for pygame._view, required for develop releases between
#    2011-02-08 and 2011-08-31, including prebuilt-pygame1.9.2a0
# Author: htgoebel
# Date: 2011-11-18
# Ticket: #406

hiddenimports = ['pygame._view']
