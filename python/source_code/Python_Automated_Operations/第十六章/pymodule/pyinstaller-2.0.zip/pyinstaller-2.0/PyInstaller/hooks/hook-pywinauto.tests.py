hiddenimports = [
            "allcontrols",
            "asianhotkey",
            "comboboxdroppedheight",
            "comparetoreffont",
            "leadtrailspaces",
            "miscvalues",
            "missalignment",
            "missingextrastring",
            "overlapping",
            "repeatedhotkey",
            "translation",
            "truncation",
]
