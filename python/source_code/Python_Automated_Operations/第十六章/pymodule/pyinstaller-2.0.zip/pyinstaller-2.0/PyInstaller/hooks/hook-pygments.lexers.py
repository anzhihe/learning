
hiddenimports = ['agile', 'dotnet']
