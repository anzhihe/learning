#!/usr/bin/env python

import os
import sys

os.chdir(sys._MEIPASS)

import data6

print os.getcwd()
