assert "foo".decode("ascii") == u"foo"
