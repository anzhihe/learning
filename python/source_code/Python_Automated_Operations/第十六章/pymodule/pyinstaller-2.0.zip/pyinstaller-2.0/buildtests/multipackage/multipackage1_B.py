#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import httplib
import gzip

def main():
    print "Hello World!"

if __name__ == "__main__":
    main()
