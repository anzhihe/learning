int dummy(int arg)
{
    return arg;
}
