This is a package for testing eggs in `PyInstaller`_

:Author:    Hartmut Goebel <h.goebel@goebel-consult.de>
:Copyright: 2012 by Hartmut Goebel
:Licence:   GNU Public Licence v3 (GPLv3)

_PyInstaller: www.pyinstaller.org
