# -*- coding: utf-8 -*-
from Public_lib import *

#查看最新登录模块#

class Modulehandle():
    def __init__(self,moduleid,hosts,sys_param_row):
        self.hosts = ""
        self.Runresult = ""
        self.moduleid = moduleid
        self.sys_param_array= sys_param_row
        self.hosts=target_host(hosts,"IP")

    def run(self):
        try:          
            self.Runresult = Order_Run(host=self.hosts, module_name='shell', module_args="/usr/bin/tail -"+str(self.sys_param_array[0])+" /var/log/secure")
            if len(self.Runresult["failed"]) == 0 and len(self.Runresult["success"]) == 0 and len(self.Runresult["unreachable"]) == 0:
                return "No hosts found,请确认主机已经添加ansible环境！"
        except Exception,e:
            return str(e)
        return self.Runresult
