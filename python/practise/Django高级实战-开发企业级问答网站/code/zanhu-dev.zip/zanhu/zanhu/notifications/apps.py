#!/usr/bin/python3
# -*- coding:utf-8 -*-
# __author__ = '__Jack__'

from django.apps import AppConfig


class NotificationsConfig(AppConfig):
    name = 'zanhu.notifications'
    verbose_name = '通知'
