#!/usr/bin/python3
# -*- coding:utf-8 -*-
# __author__ = '__Jack__'

from django.apps import AppConfig


class NewsConfig(AppConfig):
    name = 'zanhu.news'
    verbose_name = '赞乎'
