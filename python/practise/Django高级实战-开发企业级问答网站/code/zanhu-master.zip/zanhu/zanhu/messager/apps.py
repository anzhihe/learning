#!/usr/bin/python3
# -*- coding:utf-8 -*-
# __author__ = '__Jack__'

from django.apps import AppConfig


class MessagerConfig(AppConfig):
    name = 'zanhu.messager'
    verbose_name = '消息'
